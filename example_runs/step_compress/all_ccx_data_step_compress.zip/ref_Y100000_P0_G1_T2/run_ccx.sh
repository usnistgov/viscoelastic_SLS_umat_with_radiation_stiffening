#!/bin/sh

export OMP_NUM_THREADS=1

~/calculix_build/ccx_gnu_umat/ccx_2.20_MT step_compress_umat >> stdout.log
